<script setup></script>

<template>
  <header>
    <h1>Lista de compras 🛒</h1>
  </header>
</template>

<style scoped></style>
