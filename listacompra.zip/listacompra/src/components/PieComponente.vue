<script setup></script>

<template>
  <footer>
    <hr />
    <p>Sergio Menchén Pérez - 2024</p>
  </footer>
</template>

<style scoped>
footer {
  margin-top: 30px;
  text-align: center;
  font-size: medium;
}
</style>
